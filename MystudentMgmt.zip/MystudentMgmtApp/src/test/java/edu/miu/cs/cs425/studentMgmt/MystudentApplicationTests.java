package edu.miu.cs.cs425.studentMgmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MystudentApplicationTests {

	@Test
	void contextLoads() {
	}

}
