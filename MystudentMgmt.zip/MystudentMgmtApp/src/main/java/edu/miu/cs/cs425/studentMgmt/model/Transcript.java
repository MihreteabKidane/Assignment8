package edu.miu.cs.cs425.studentMgmt.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "transcript")
public class Transcript {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
//	@Column(name = "transcript_id")
	private long transcriptId;

	@Column(name = "degree_title")
	private String degreeTitle;

	@OneToOne(mappedBy = "transcript")
	private Student student;

	public Transcript() {
	}

	public Transcript(long transcriptId, String degreeTitle) {
		super();
		this.transcriptId = transcriptId;
		this.degreeTitle = degreeTitle;
	}

	public Transcript(String degreeTitle) {
		this.degreeTitle = degreeTitle;
	}

	public Transcript(String degreeTitle, Student student) {
		this.degreeTitle = degreeTitle;
		this.student = student;
	}

	public Transcript(long transcriptId, String degreeTitle, Student student) {
		this.transcriptId = transcriptId;
		this.degreeTitle = degreeTitle;
		this.student = student;
	}

	public Long getTranscriptId() {
		return transcriptId;
	}

	public void setTranscriptId(Long transcriptId) {
		this.transcriptId = transcriptId;
	}

	public String getDegreeTitle() {
		return degreeTitle;
	}

	public void setDegreeTitle(String degreeTitle) {
		this.degreeTitle = degreeTitle;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	@Override
	public String toString() {
		return String.format("Transcript [transcriptId=%s, degreeTitle=%s, student=%s]", transcriptId, degreeTitle,
				student);
	}

}
