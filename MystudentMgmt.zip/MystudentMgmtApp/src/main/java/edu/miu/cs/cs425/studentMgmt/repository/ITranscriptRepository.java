package edu.miu.cs.cs425.studentMgmt.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import edu.miu.cs.cs425.studentMgmt.model.Transcript;

@Repository
public interface ITranscriptRepository extends CrudRepository<Transcript, Long> {
}
