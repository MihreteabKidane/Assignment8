package edu.miu.cs.cs425.studentMgmt.repository;

import org.springframework.data.repository.CrudRepository;

import edu.miu.cs.cs425.studentMgmt.model.Classroom;


public interface IClassroomRepository extends CrudRepository<Classroom, Long>{

}
