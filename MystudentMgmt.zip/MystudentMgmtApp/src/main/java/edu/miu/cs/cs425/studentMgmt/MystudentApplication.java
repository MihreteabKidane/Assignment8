package edu.miu.cs.cs425.studentMgmt;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import edu.miu.cs.cs425.studentMgmt.model.Classroom;
import edu.miu.cs.cs425.studentMgmt.model.Student;
import edu.miu.cs.cs425.studentMgmt.model.Transcript;
import edu.miu.cs.cs425.studentMgmt.repository.IClassroomRepository;
import edu.miu.cs.cs425.studentMgmt.repository.IStudentRepository;
import edu.miu.cs.cs425.studentMgmt.repository.ITranscriptRepository;

@SpringBootApplication
public class MystudentApplication implements CommandLineRunner {

	@Autowired
	private IStudentRepository studentRepository;
	@Autowired
	private ITranscriptRepository transcriptRepository;
	@Autowired
	private IClassroomRepository classroomRepository;

	public static void main(String[] args) {
		SpringApplication.run(MystudentApplication.class, args);

	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println("Hello Student");

		Transcript tr1 = new Transcript("BSC Computer Science");
		Transcript tr2 = new Transcript("MSC Mathematics");
		Transcript tr3 = new Transcript("BSC Biology");
		Transcript tr4 = new Transcript("MSC Linguistics");
		Transcript tr5 = new Transcript("BSC Civil Engineering");

		Classroom cl1 = new Classroom("McLaughlin building", "M105");
		Classroom cl2 = new Classroom("Utopia park building", "E1");
		Classroom cl3 = new Classroom("VerilHall building", "V32");
		Classroom cl4 = new Classroom("Drier building", "D05");
		Classroom cl5 = new Classroom("Argiro building", "A15");

		Student s1 = new Student("000-61-0001", "Anna", "Lynn", "Smith", 3.45, LocalDate.of(2019, 5, 24), tr1, cl1);
		Student s2 = new Student("000-61-0002", "Simon", "Tsegai", "Kidane", 3.92, LocalDate.of(2018, 10, 10), tr2,
				cl2);
		Student s3 = new Student("000-61-0003", "Selam", "Tsegai", "Kidane", 3.88, LocalDate.of(2017, 11, 23), tr3,
				cl3);
		Student s4 = new Student("000-61-0004", "Anna", "Lynn", "Smith", 3.45, LocalDate.of(2020, 1, 11), tr4, cl4);
		Student s5 = new Student("000-61-0005", "Anna", "Lynn", "Smith", 3.45, LocalDate.of(2020, 3, 6), tr5, cl5);
		Student[] sts = { s1, s2, s3, s4, s5 };
		for (Student s : sts) {
			studentRepository.save(s);
		}

		// studentRepository.save(s1);
	}

}
